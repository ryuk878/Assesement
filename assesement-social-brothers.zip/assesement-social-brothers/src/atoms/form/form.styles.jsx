import styled from "styled-components";

const StyledInputForm = styled.input`
  background-color: #fafafa;
`;

export default StyledInputForm;
