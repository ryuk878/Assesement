import styled from "styled-components";

const StyledParagraph = styled.p`
  color: #ffffff;
  font-family: Inter;
  font-size: 12px;

`;

export default StyledParagraph;
