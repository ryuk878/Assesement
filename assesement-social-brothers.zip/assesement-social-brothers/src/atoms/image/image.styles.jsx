import styled from "styled-components";

const StyledHeaderImage = styled.img`
  width: 100%;
  height: 208px;
 
`;

export default StyledHeaderImage;

