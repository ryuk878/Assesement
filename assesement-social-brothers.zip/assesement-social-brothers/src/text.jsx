export const text = {
  Button: {
    createMessage: "bericht aanmaken",
    loadMore: "Meer Laden",
  },

  Header: {
    TitleHeader: "Plaats een blog bericht",
  },

  Paragraph: {
    test: "test",
  },
  Footer: {
    footerText: "Copyright Social Brothers - 2023",
  },
  BlogPost: {
    createMessage: "Plaats een blog bericht",
    messageName: "Berichtnaam",
    category: "Categorie",
    imageHeader: "Header afbeelding",
    button: "Kies bestand",
    message: "Bericht",
  },
  BlogText: {
    dummyText:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus eget metus blandit, pharetra nisi eu, aliquet leo. risus, id lobortis massa ultrices nec.",
    date: "23/01/2024",
    category: "Categorie"
  },
};
