import styled from "styled-components"

const PageContainer = styled.div`
 display: flex; 
 gap : 24px;

`

export { PageContainer }